# UserAccountControl AD (UAC)

A Pen created on CodePen.

Original URL: [https://codepen.io/celodacruz/pen/ZYEBxRL](https://codepen.io/celodacruz/pen/ZYEBxRL).

